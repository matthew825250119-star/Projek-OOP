import com.bbm.BahanBakar;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Penjualan implements Cetak {
    private String noStruk;
    private String tanggalWaktu;
    private String metodePembayaran;
    private BahanBakar bbm;
    private double volume;
    private Seller kasir;
    private Buyer pelanggan;

    public Penjualan(String noStruk, String tanggalWaktu, String metodePembayaran,
                     Seller kasir, Buyer pelanggan, BahanBakar bbm, double volume) {
        this.noStruk = noStruk;
        this.tanggalWaktu = tanggalWaktu;
        this.metodePembayaran = metodePembayaran;
        this.kasir = kasir;
        this.pelanggan = pelanggan;
        this.bbm     = bbm;
        this.volume = volume;
    }

    public Penjualan() {
    }

    public void setNoStruk(String noStruk) { this.noStruk = noStruk; }
    public String getNoStruk() { return noStruk; }

    public void setTanggalWaktu(String tanggalWaktu) { this.tanggalWaktu = tanggalWaktu; }
    public String getTanggalWaktu() { return tanggalWaktu; }

    public void setMetodePembayaran(String metodePembayaran) { this.metodePembayaran = metodePembayaran; }
    public String getMetodePembayaran() { return metodePembayaran; }

    public void setKasir(Seller kasir) { this.kasir = kasir; }
    public Seller getKasir() { return kasir; }

    public void setPelanggan(Buyer pelanggan) { this.pelanggan = pelanggan; }
    public Buyer getPelanggan() { return pelanggan; }

    public void setBahanBakar(BahanBakar bbm) { this.bbm = bbm; }
    public BahanBakar getBahanBakar() { return bbm; }

    public void setVolume(double volume) { this.volume = volume; }
    public double getVolume() { return volume; }

    public double hitungTotal() {
        return bbm.hitungTotal(volume);
    }

    // Implementasi interface Cetak: menyusun teks struk, menampilkannya di console,
    // lalu menyimpannya ke file struk/<noStruk>.txt
    public void struk() {
        StringBuilder sb = new StringBuilder();
        sb.append(TOKO).append("\n");
        sb.append(ALAMAT).append("\n");
        sb.append("TELP. ").append(NO_TELPON).append("\n");
        sb.append("--------------------------------\n");
        sb.append("STRUK PENJUALAN\n");
        sb.append("Nomor      : ").append(noStruk).append("\n");
        sb.append("Tanggal    : ").append(tanggalWaktu).append("\n");
        sb.append("Pembayaran : ").append(metodePembayaran).append("\n");
        sb.append("Plat       : ").append(pelanggan.getNoPolisi()).append("\n");
        sb.append("--------------------------------\n");
        sb.append("Jenis      : ").append(bbm.getJenisBahanBakar()).append("\n");
        sb.append("Produk     : ").append(bbm.getInfoJenis()).append("\n");
        sb.append(String.format("Harga      : Rp %,.0f%n", bbm.getHargaPerLiter()));
        sb.append(String.format("Volume     : %.2f L%n", volume));
        sb.append("--------------------------------\n");
        sb.append(String.format("Total      : Rp %,.0f%n", hitungTotal()));
        sb.append("Kasir      : ").append(kasir.getNama()).append("\n");

        System.out.print(sb);
        simpan(sb.toString());
    }

    private void simpan(String isistruk) {
        Path path = Paths.get("struk", noStruk + ".txt");
        try {
            Files.createDirectories(path.getParent());
            Files.write(path, isistruk.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Gagal menyimpan struk ke file: " + e.getMessage());
        }
    }
}
