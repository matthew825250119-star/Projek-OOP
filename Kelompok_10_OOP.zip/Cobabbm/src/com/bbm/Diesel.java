package com.bbm;

public class Diesel extends BahanBakar {
    private int cetane;

    public Diesel(String namaBahanBakar, double hargaPerLiter, int cetane) {
        super("Diesel", namaBahanBakar, hargaPerLiter);
        this.cetane = cetane;
    }

    public int getCetane() {
        return cetane;
    }

    public void setCetane(int cetane) {
        this.cetane = cetane;
    }

    public double hitungTotal(double volume) {
        return getHargaPerLiter() * volume;
    }

    public String getInfoJenis() {
        return getNama() + " (Cetane " + cetane + ")";
    }
}