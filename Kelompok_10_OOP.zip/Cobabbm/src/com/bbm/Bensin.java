package com.bbm;

public class Bensin extends BahanBakar {
    private int ron;

    public Bensin(String namaBahanBakar, double hargaPerLiter, int ron) {
        super("Bensin", namaBahanBakar, hargaPerLiter);
        this.ron = ron;
    }

    public int getRon() {
        return ron;
    }

    public void setRon(int ron) {
        this.ron = ron;
    }

    public double hitungTotal(double volume) {
        return getHargaPerLiter() * volume;
    }

    public String getInfoJenis() {
        return getNama() + " (RON " + ron + ")";
    }
}