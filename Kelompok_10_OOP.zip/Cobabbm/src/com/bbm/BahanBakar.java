package com.bbm;

public abstract class BahanBakar {
    private String jenisBahanBakar;
    private String namaBahanBakar;
    private double hargaPerLiter;

    public BahanBakar(String jenisBahanBakar, String namaBahanBakar, double hargaPerLiter) {
        this.jenisBahanBakar = jenisBahanBakar;
        this.namaBahanBakar = namaBahanBakar;
        this.hargaPerLiter = hargaPerLiter;
    }

    public void setJenisBahanBakar(String jenisBahanBakar) {
        this.jenisBahanBakar = jenisBahanBakar;
    }

    public String getJenisBahanBakar() {
        return jenisBahanBakar;
    }

    public void setNama(String namaBahanBakar) {
        this.namaBahanBakar = namaBahanBakar;
    }

    public String getNama() {
        return namaBahanBakar;
    }

    public void setHargaPerLiter(double hargaPerLiter) {
        this.hargaPerLiter = hargaPerLiter;
    }

    public double getHargaPerLiter() {
        return hargaPerLiter;
    }

    // wajib diimplementasikan subclass
    public abstract double hitungTotal(double volume);
    public abstract String getInfoJenis();
}
