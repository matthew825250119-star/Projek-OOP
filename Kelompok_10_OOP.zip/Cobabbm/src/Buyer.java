public class Buyer {
    private String noPolisi;

    public Buyer(String noPolisi) {
        this.noPolisi = noPolisi;
    }

    public Buyer() {
    }

    public void setNoPolisi(String noPolisi) {
        this.noPolisi = noPolisi;
    }

    public String getNoPolisi() {
        return noPolisi;
    }
}
