public interface Cetak {
    // Toko & noTelpon di diagram bertipe int, tapi datanya (nama toko, nomor telp dengan strip)
    // tidak valid sebagai int, jadi di sini dipakai String supaya bisa dipakai sebagaimana mestinya.
    String TOKO = "SPBU 34-11806";
    String ALAMAT = "Jl. Satu Maret, Kalideres - Jakarta Barat";
    String NO_TELPON = "021-54368076";

    void struk();
}
