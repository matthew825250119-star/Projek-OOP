import com.bbm.BahanBakar;
import com.bbm.Bensin;
import com.bbm.Diesel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {

    // Urutan di sini = nomor menu (1..5)
    private static final BahanBakar[] DAFTAR = {
        new Bensin("Pertalite", 10000, 90),
        new Bensin("Pertamax", 13000, 92),
        new Bensin("Pertamax Turbo", 19600, 98),
        new Diesel("Solar", 6800, 48),
        new Diesel("Dexlite", 13500, 51)
    };
    private static final String[] METODE = {"Tunai", "E-Wallet", "Debit"};

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int urutan = 1;

        // Kasir yang sedang bertugas (bisa diganti kalau nanti ada login per shift)
        Seller kasir = new Seller("K01", "Budi");

        tampilkanDaftarHarga();

        int pilihan = bacaPilihan(sc);
        String plat = bacaPlat(sc);
        double volume = bacaVolume(sc);
        int bayar = bacaPembayaran(sc);
        String metode = METODE[bayar - 1];

        LocalDateTime sekarang = LocalDateTime.now();
        String tanggal = sekarang.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
        String nomor = "STH" + sekarang.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
                + String.format("%02d", urutan);

        BahanBakar bbm = DAFTAR[pilihan - 1];
        Buyer pelanggan = new Buyer(plat);

        Penjualan transaksi = new Penjualan(nomor, tanggal, metode, kasir, pelanggan, bbm, volume);
        transaksi.struk();

        System.out.println();
        System.out.println("Struk berhasil dibuat");
        System.out.println();

        System.out.println("Terima kasih.");
        sc.close();
    }

    private static void tampilkanDaftarHarga() {
        System.out.println("===== DAFTAR HARGA BBM (per liter) =====");
        String jenisSebelumnya = "";
        for (int i = 0; i < DAFTAR.length; i++) {
            BahanBakar bb = DAFTAR[i];
            if (!bb.getJenisBahanBakar().equals(jenisSebelumnya)) {
                System.out.println(bb.getJenisBahanBakar().toUpperCase());
                jenisSebelumnya = bb.getJenisBahanBakar();
            }
            System.out.printf("  %d. %-15s Rp %,.0f%n", i + 1, bb.getNama(), bb.getHargaPerLiter());
        }
        System.out.println("========================================");
    }

    private static int bacaPilihan(Scanner sc) {
        while (true) {
            System.out.print("Pilih BBM (1-" + DAFTAR.length + ") : ");
            try {
                int pilihan = Integer.parseInt(sc.nextLine().trim());
                if (pilihan >= 1 && pilihan <= DAFTAR.length) {
                    return pilihan;
                }
            } catch (NumberFormatException e) {
                // jatuh ke pesan di bawah
            }
            System.out.println("Pilihan tidak valid, masukkan angka 1-" + DAFTAR.length + ".");
        }
    }

    private static String bacaPlat(Scanner sc) {
        while (true) {
            System.out.print("Plat kendaraan       : ");
            String plat = sc.nextLine().trim().toUpperCase();
            if (!plat.isEmpty()) {
                return plat;
            }
            System.out.println("Plat tidak boleh kosong.");
        }
    }

    private static double bacaVolume(Scanner sc) {
        while (true) {
            System.out.print("Jumlah liter         : ");
            try {
                double volume = Double.parseDouble(sc.nextLine().trim().replace(',', '.'));
                if (volume > 0) {
                    return volume;
                }
            } catch (NumberFormatException e) {
                // jatuh ke pesan di bawah
            }
            System.out.println("Jumlah liter tidak valid, masukkan angka lebih dari 0.");
        }
    }

    private static int bacaPembayaran(Scanner sc) {
        System.out.println("Metode pembayaran:");
        for (int i = 0; i < METODE.length; i++) {
            System.out.println("  " + (i + 1) + ". " + METODE[i]);
        }
        while (true) {
            System.out.print("Pilih pembayaran (1-" + METODE.length + ") : ");
            try {
                int pilihan = Integer.parseInt(sc.nextLine().trim());
                if (pilihan >= 1 && pilihan <= METODE.length) {
                    return pilihan;
                }
            } catch (NumberFormatException e) {
                // jatuh ke pesan di bawah
            }
            System.out.println("Pilihan tidak valid, masukkan angka 1-" + METODE.length + ".");
        }
    }
}
